# Simple Inline Markup Language and Logging (saimll)
