from saimll import SAIML

SAIML.print("[@F red]Hello")