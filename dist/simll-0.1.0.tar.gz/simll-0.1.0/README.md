# Simple Inline Markup Language and Logging (simll)
