from .log import Log, Logger
from .LogLevel import LogLevel
